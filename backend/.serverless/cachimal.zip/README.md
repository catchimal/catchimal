# gcp-node-typescript
Uses serverless framework for catcimals BE

## Credentials 
- [Google Cloud Platform credential](https://serverless.com/framework/docs/providers/google/guide/credentials/)

## Get Started 
### install dependencies
```
$ npm i
```

### deploy
```
$ serverless deploy
```


### Try it
```
$ npm start
```