exports.test = (request, response) => {
  response.status(200).send("Hello World! Let's start Typescript!!");
};